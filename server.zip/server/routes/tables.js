
console.log("✅ /api/tables router yüklendi");

const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const { v4: uuidv4 } = require("uuid");

const TABLES_FILE = path.join(__dirname, "..", "data", "tables.json");
const SALES_FILE = path.join(__dirname, "..", "data", "sales.json");

function readJSON(file) {
  try {
    return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file)) : [];
  } catch (err) {
    console.error(`❌ JSON okuma hatası (${file}):`, err.message);
    return [];
  }
}

function detectPOSPort() {
  try {
    const output = execSync("wmic path Win32_SerialPort get DeviceID,Description").toString();
    const lines = output.split("\n").filter(line => line.includes("POS") || line.includes("USB"));
    const match = lines[0]?.match(/(COM\d+)/);
    return match ? match[1] : null;
  } catch (err) {
    console.error("❌ COM port algılanamadı:", err.message);
    return null;
  }
}

function sendToPOSPort(total, tableName) {
  const port = detectPOSPort();
  if (!port) return;
  const content = `Masa: ${tableName}\nToplam: ${total.toFixed(2)}₺\nÖdeme: Kart\n`;
  try {
    execSync(`echo ${content} > \\.\\${port}`);
    console.log("✅ POS yönlendirmesi yapıldı =>", port);
  } catch (err) {
    console.error("❌ POS yazdırma hatası:", err.message);
  }
}

router.get("/", (req, res) => {
  try {
    const tables = readJSON(TABLES_FILE);
    res.json(tables);
  } catch (err) {
    res.status(500).json({ error: "Tablo verileri okunamadı" });
  }
});

router.get("/:id", (req, res) => {
  const tables = readJSON(TABLES_FILE);
  const table = tables.find((t) => t.id === req.params.id);
  if (!table) return res.status(404).json({ error: "Masa bulunamadı" });
  res.json(table);
});

router.post("/", (req, res) => {
  const tables = readJSON(TABLES_FILE);
  const newTable = {
    id: uuidv4(),
    name: req.body.name,
    status: "empty",
    orders: []
  };
  tables.push(newTable);
  fs.writeFileSync(TABLES_FILE, JSON.stringify(tables, null, 2));
  res.status(201).json(newTable);
});

router.delete("/:id", (req, res) => {
  let tables = readJSON(TABLES_FILE);
  tables = tables.filter((t) => t.id !== req.params.id);
  fs.writeFileSync(TABLES_FILE, JSON.stringify(tables, null, 2));
  res.status(204).send();
});

router.post("/:id/order", (req, res) => {
  const tables = readJSON(TABLES_FILE);
  const table = tables.find((t) => t.id === req.params.id);
  if (!table) return res.status(404).json({ error: "Masa bulunamadı" });

  const order = req.body;
  const existing = table.orders.find((o) => o.id === order.id);
  if (existing) {
    existing.qty += 1;
  } else {
    table.orders.push({ ...order, qty: 1 });
  }

  table.status = "occupied";
  fs.writeFileSync(TABLES_FILE, JSON.stringify(tables, null, 2));
  req.io.emit("tables:update", tables);

  res.json(table);
});

router.post("/:id/remove", (req, res) => {
  const tables = readJSON(TABLES_FILE);
  const table = tables.find((t) => t.id === req.params.id);
  if (!table) return res.status(404).json({ error: "Masa bulunamadı" });

  const productId = req.body.id;
  table.orders = table.orders.filter((o) => o.id !== productId);
  if (table.orders.length === 0) table.status = "empty";

  fs.writeFileSync(TABLES_FILE, JSON.stringify(tables, null, 2));
  req.io.emit("tables:update", tables);

  res.json(table);
});

router.post("/:id/pay", (req, res) => {
  const { paymentMethod } = req.body;
  const tables = readJSON(TABLES_FILE);
  const table = tables.find((t) => t.id === req.params.id);
  if (!table) return res.status(404).json({ error: "Masa bulunamadı" });

  const orderTotal = table.orders.reduce((sum, item) => sum + item.price * item.qty, 0);
  const kdv = orderTotal * 0.08;
  const servis = orderTotal * 0.05;
  const total = orderTotal + kdv + servis;

  const rapor = readJSON(SALES_FILE);
  rapor.push({
    tableId: table.id,
    orders: table.orders,
    total,
    kdv,
    servis,
    paymentMethod,
    date: new Date().toISOString()
  });

  fs.writeFileSync(SALES_FILE, JSON.stringify(rapor, null, 2));

  if (paymentMethod === "card") {
    sendToPOSPort(total, table.name);
  }

  table.orders = [];
  table.status = "empty";
  fs.writeFileSync(TABLES_FILE, JSON.stringify(tables, null, 2));
  req.io.emit("tables:update", tables);

  res.json({ success: true });
});

module.exports = router;
