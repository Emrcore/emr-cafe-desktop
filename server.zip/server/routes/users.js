const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");
const bcrypt = require("bcrypt");

const USERS_FILE = path.join(__dirname, "..", "data", "users.json");

router.get("/", (req, res) => {
  const users = JSON.parse(fs.readFileSync(USERS_FILE));
  const safeUsers = users.map((u) => ({ username: u.username, role: u.role }));
  res.json(safeUsers);
});

router.post("/", async (req, res) => {
  const { username, password, role } = req.body;
  const users = JSON.parse(fs.readFileSync(USERS_FILE));

  if (users.find((u) => u.username === username)) {
    return res.status(400).json({ message: "Kullanıcı zaten var" });
  }

  const hashed = await bcrypt.hash(password, 10);
  users.push({ username, password: hashed, role });
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));

  res.json({ message: "Kullanıcı eklendi" });
});

router.delete("/:username", (req, res) => {
  const users = JSON.parse(fs.readFileSync(USERS_FILE));
  const filtered = users.filter((u) => u.username !== req.params.username);
  fs.writeFileSync(USERS_FILE, JSON.stringify(filtered, null, 2));
  res.json({ message: "Kullanıcı silindi" });
});

module.exports = router;
