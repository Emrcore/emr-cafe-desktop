const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

const LICENSE_FILE = path.join(__dirname, "..", "data", "license.json");

router.post("/", (req, res) => {
  const license = JSON.parse(fs.readFileSync(LICENSE_FILE));
  const { lisansKey, cihazId } = req.body;

  const isValid =
    license.lisansKey === lisansKey &&
    license.cihazId === cihazId &&
    license.valid === true;

  res.json({ valid: isValid });
});

module.exports = router;
