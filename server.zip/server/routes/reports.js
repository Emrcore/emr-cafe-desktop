const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");
const XLSX = require("xlsx");

const SALES_FILE = path.join(__dirname, "..", "data", "sales.json");

// JSON rapor (isteğe bağlı tarih filtreli)
router.get("/", (req, res) => {
  const allSales = fs.existsSync(SALES_FILE)
    ? JSON.parse(fs.readFileSync(SALES_FILE))
    : [];

  const { date } = req.query;
  if (date) {
    const filtered = allSales.filter((s) => s.date.startsWith(date));
    return res.json(filtered);
  }

  res.json(allSales);
});

// Excel çıktısı
router.get("/excel", (req, res) => {
  const allSales = fs.existsSync(SALES_FILE)
    ? JSON.parse(fs.readFileSync(SALES_FILE))
    : [];

  const flatRows = allSales.flatMap((sale) =>
    sale.orders.map((o) => ({
      Tarih: new Date(sale.date).toLocaleString(),
      Masa: sale.tableId,
      Ürün: o.name,
      Adet: o.qty,
      Fiyat: o.price,
      AraToplam: o.price * o.qty,
      KDV: sale.kdv.toFixed(2),
      Servis: sale.servis.toFixed(2),
      GenelToplam: sale.total.toFixed(2),
      Ödeme: sale.paymentMethod
    }))
  );

  const worksheet = XLSX.utils.json_to_sheet(flatRows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Satışlar");

  const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
  res.setHeader("Content-Disposition", "attachment; filename=rapor.xlsx");
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.send(buffer);
});

module.exports = router;
