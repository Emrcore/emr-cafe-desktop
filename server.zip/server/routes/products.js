const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");
const { v4: uuidv4 } = require("uuid");

const PRODUCTS_FILE = path.join(__dirname, "..", "data", "products.json");

function readJSON(file) {
  try {
    return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file)) : [];
  } catch (err) {
    console.error(`❌ JSON okuma hatası (${file}):`, err.message);
    return [];
  }
}

router.get("/", (req, res) => {
  const products = readJSON(PRODUCTS_FILE);
  res.json(products);
});

router.post("/", (req, res) => {
  const products = readJSON(PRODUCTS_FILE);
  const newProduct = {
    id: uuidv4(),
    name: req.body.name,
    price: Number(req.body.price),
    category: req.body.category || "Genel"
  };
  products.push(newProduct);
  fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2));
  res.status(201).json(newProduct);
});

router.delete("/:id", (req, res) => {
  let products = readJSON(PRODUCTS_FILE);
  products = products.filter((p) => p.id !== req.params.id);
  fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2));
  res.status(204).send();
});

module.exports = router;
