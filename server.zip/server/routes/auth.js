const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const fs = require("fs");
const path = require("path");

const USERS_FILE = path.join(__dirname, "..", "data", "users.json");

router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const users = JSON.parse(fs.readFileSync(USERS_FILE));
    const user = users.find((u) => u.username === username);

    if (!user) {
      console.log("❌ Kullanıcı bulunamadı:", username);
      return res.status(401).json({ error: "Kullanıcı bulunamadı" });
    }

    const match = await bcrypt.compare(password, user.password);
    console.log("🔑 Gelen şifre:", password);
    console.log("🔒 Hash:", user.password);
    console.log("✅ Match sonucu:", match);

    if (!match) {
      console.log("❌ Şifre hatalı:", username);
      return res.status(401).json({ error: "Şifre hatalı" });
    }

    console.log("✅ Giriş başarılı:", username);
    res.json({ username: user.username, role: user.role });

  } catch (err) {
    console.error("❌ Giriş sırasında hata:", err.message);
    res.status(500).json({ error: "Sunucu hatası" });
  }
});

module.exports = router;
