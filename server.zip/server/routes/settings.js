const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

const SETTINGS_FILE = path.join(__dirname, "..", "data", "settings.json");

router.get("/", (req, res) => {
  const settings = JSON.parse(fs.readFileSync(SETTINGS_FILE));
  res.json(settings);
});

router.post("/", (req, res) => {
  const settings = req.body;
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  res.json({ message: "Ayarlar güncellendi" });
});

module.exports = router;
