const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");

const authRouter = require("./routes/auth");
const tableRouter = require("./routes/tables");
const reportRouter = require("./routes/reports");
const userRouter = require("./routes/users");
const settingsRouter = require("./routes/settings");
const productRouter = require("./routes/products");
const licenseRouter = require("./routes/license");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());

// 💡 Socket erişimi sağlamak için önce middleware
app.use((req, res, next) => {
  req.io = io;
  next();
});

// 🔌 Tüm API router'lar
app.use("/api/reports", reportRouter);
app.use("/api/products", productRouter);
app.use("/api/settings", settingsRouter);
app.use("/api/users", userRouter);
app.use("/api/license", licenseRouter);
app.use("/api", authRouter);
app.use("/api/tables", tableRouter);

// 🟢 Test route
app.get("/", (req, res) => res.send("EMR Cafe Sunucu Aktif"));

// 🧩 Socket bağlantısı
io.on("connection", (socket) => {
  console.log("Yeni bağlantı:", socket.id);
});

server.listen(3001, () => console.log("Sunucu çalışıyor: 3001"));
