// Mobile-friendly, modern navigation using Tailwind CSS
import { Link, useLocation } from "react-router-dom";

export default function MobileNav() {
  const { pathname } = useLocation();

  const navItems = [
    { path: "/", label: "Masalar" },
    { path: "/report", label: "Rapor" },
    { path: "/users", label: "Kullanıcılar" },
    { path: "/settings", label: "Ayarlar" }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-md flex justify-around items-center h-14 z-50">
      {navItems.map((item) => (
        <Link
          key={item.path}
          to={item.path}
          className={`text-sm font-medium flex flex-col items-center justify-center h-full px-2 transition duration-200 ${
            pathname === item.path ? "text-blue-600" : "text-gray-600"
          }`}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  );
}
