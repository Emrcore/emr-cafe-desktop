import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Tables from "./pages/Tables.jsx";
import TableDetail from "./pages/TableDetail.jsx";
import UserManagement from "./pages/UserManagement.jsx";
import Settings from "./pages/Settings.jsx";
import Report from "./pages/Report.jsx";
import Login from "./pages/Login.jsx";
import MobileNav from "./components/MobileNav";

export default function App() {
  return (
    <Router>
      <div className="pb-16">
        <Routes>
          <Route path="/" element={<Tables />} />
          <Route path="/table/:id" element={<TableDetail />} />
          <Route path="/users" element={<UserManagement />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/report" element={<Report />} />
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<h1 style={{ padding: 50 }}>404 — Sayfa bulunamadı</h1>} />
        </Routes>
        <MobileNav />
      </div>
    </Router>
  );
}
